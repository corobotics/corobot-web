function formhash(form, id, password) {
    if (id.value == ""){
        alert ("Please enter your RIT id");
        return false;
    }
    else if (password.value == "") {
        alert ("Please enter your RIT password");
        return false;
    }
    else {
        // Create a new element input, this will be our hashed password field. 
        var p = document.createElement("input");
     
        // Add the new element to our form. 
        form.appendChild(p);
        p.name = "p";
        p.type = "hidden";
        p.value = password.value;
     
        // Make sure the plaintext password doesn't get sent. 
        password.value = "";
     
        // Finally submit the form. 
        form.submit();
        return true;
    }
}