<?php
/**
* These are the database login details
*/  
    define("HOST", "localhost");     // The host you want to connect to.
    define("USER", "www");    // The database username. 
    define("PASSWORD", "");    // The database password. 
    define("DATABASE", "login_info");    // The database name.
     
    define("CAN_REGISTER", "any");
    define("DEFAULT_ROLE", "member");
     
    define("SECURE", TRUE); // For testing purpose. Toggle to TRUE for production.
?>