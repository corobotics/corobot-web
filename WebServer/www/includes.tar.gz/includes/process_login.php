<?php
    include_once 'db_connect.php';
    include_once 'functions.php';
    include_once 'authenticate.php';
    include_once 'folder_setup.php';
    include_once 'db_names.php';
    // Securely start the session.
    sec_session_start();
    
    if (isset($_POST['id'], $_POST['p'])) {
        $id = $_POST['id'];
        $password = $_POST['p'];
        if (authenticate($id,$password, $mysqli) == true) {
            // Admin logs
            if (isset($_SESSION['admin']) && ($_SESSION['admin'])) {
                // Check if the folders and files exist or not - admin.
                createFoldersAndFiles ($id,true);
                // Admin logs
                generateAdminLogs ($mysqli);
            } else {
                // Check if the folders and files exist or not.
                createFoldersAndFiles ($id,false);
            }
            header('Location: /workspace.php');
        } else {
            // Login failed 
            header('Location: /error.php?err="Invalid login details"');
        }
        
    } else {
        // The correct POST variables were not sent to this page. 
        echo 'Invalid Request';
    }
?>