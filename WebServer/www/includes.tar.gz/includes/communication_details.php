<?php
    $filename = '/var/www/includes/server_details.json';
    $handler = fopen ($filename, 'r') or die ('Unable to open json file');
    $result = json_decode (fread ($handler, filesize ($filename))) or die ('Unable to open json file');
    foreach ($result as $key => $value)
        define($key, $value);
?>