<?php
    include_once 'db_config.php';
    include_once 'db_names.php';
    include_once 'folder_config.php';

    // Function to securely start a session.
    function sec_session_start() {
        $session_name = 'corobotics_login_session';   // Set a custom session name
        $secure = SECURE;
        // This stops JavaScript being able to access the session id.
        $httponly = true;
        // Forces sessions to only use cookies.
        if (ini_set('session.use_only_cookies', 1) === FALSE) {
            header("Location: ../error.php?err=Could not initiate a safe session (ini_set)");
            exit();
        }
        // Gets current cookies params.
        $cookieParams = session_get_cookie_params();
        session_set_cookie_params($cookieParams["lifetime"],
            $cookieParams["path"], 
            $cookieParams["domain"], 
            $secure,
            $httponly);
        // Sets the session name to the one set above.
        session_name($session_name);
        session_start();            // Start the PHP session 
        session_regenerate_id();    // regenerated the session, delete the old one. 
    }

    // Login function
    function login ($id, $password, $mysqli) {
        // Using prepared statements means that SQL injection is not possible. 
        if ($stmt = $mysqli->prepare("SELECT id, password, salt 
            FROM " . STUDENT_TABLE . " WHERE id = ?
            LIMIT 1")) {
            $stmt->bind_param('s', $id);  // Bind "$id" to parameter.
            $stmt->execute();    // Execute the prepared query.
            $stmt->store_result();
     
            // get variables from result.
            $stmt->bind_result($user_id, $db_password, $salt);
            $stmt->fetch();
            // hash the password with the unique salt.
            if ($stmt->num_rows == 1) {
                // If the user exists we check if the account is locked
                // from too many login attempts 
                
                if (checkbrute($user_id, $mysqli) == true) {
                    // Account is locked 
                    // Send an email to user saying their account is locked
                    return false;
                } 
                
                else {
                    // Check if the password in the database matches
                    // the password the user submitted.
                    if ($db_password == $password) {
                        // Password is correct!
                        // Get the user-agent string of the user.
                        $user_browser = $_SERVER['HTTP_USER_AGENT'];
                        // XSS protection as we might print this value
                        $user_id = preg_replace("/[^a-zA-Z0-9]+/", "", $user_id);
                        $_SESSION['id'] = $user_id;
                        $_SESSION['login_string'] = hash('sha512', $salt . $user_browser);
                        // Login successful.
                        return true;
                    } else {
                        // Password is not correct
                        // We record this attempt in the database
                        $now = time();
                        $mysqli->query("INSERT INTO " . OLD_LOGIN_ATTEMPT_TABLE ." VALUES ('$user_id','test', '$now'");
                        return false;
                    }
                }
            } else {
                // No user exists.
                return false;
            }
        }
    }

    // Function to validate the no. of login attempts.
    function checkbrute($id, $mysqli) {
        define("MAX_ATTEMPTS",5);
        // Get timestamp of current time
        $now = time();
     
        // All login attempts are counted from the past 2 hours. 
        $valid_attempts = $now - (2 * 60 * 60);
     
        if ($stmt = $mysqli->prepare("SELECT time 
                                 FROM " . OLD_LOGIN_ATTEMPT_TABLE . " <code><pre>
                                 WHERE id = ? 
                                AND time > '$valid_attempts'")) {
            $stmt->bind_param('s', $id);
     
            // Execute the prepared query. 
            $stmt->execute();
            $stmt->store_result();
     
            // If there have been more than 5 failed logins 
            if ($stmt->num_rows > MAX_ATTEMPTS) {
                return true;
            } else {
                return false;
            }
        }
    }

    // Function to check if user is already logged in.
    function logged_in_check($mysqli) {
        // Check if all session variables are set 
        if (isset($_SESSION['id'], $_SESSION['login_string'])) {
            $id = $_SESSION['id'];
            $login_string = $_SESSION['login_string'];
     
            // Get the user-agent string of the user.
            $user_browser = $_SERVER['HTTP_USER_AGENT'];
            if ($stmt = $mysqli->prepare("SELECT complete_name FROM " . 
                STUDENT_DETAILS_TABLE . " WHERE id = ?")) {
                // Bind "$user_id" to parameter. 
                $stmt->bind_param('s', $id);
                $stmt->execute();
                $stmt->store_result();
     
                if ($stmt->num_rows == 1) {
                    // If the user exists get variables from result.
                    $stmt->bind_result($complete_name);
                    $stmt->fetch();
                    $login_check = hash('sha512', ($user_browser . $id . $complete_name));
     
                    if ($login_check == $login_string) {
                        // Logged In!!!! 
                        return true;
                    } else {
                        // Not logged in 
                        return false;
                    }
                } else {
                    // Not logged in 
                    return false;
                }
            } else {
                // Not logged in 
                return false;
            }
        } else {
            // Not logged in 
            return false;
        }
    }

    // Sanitize output from PHP_SELF
    function esc_url($url) {
        if ('' == $url) {
            return $url;
        }
        $url = preg_replace('|[^a-z0-9-~+_.?#=!&;,/:%@$\|*\'()\\x80-\\xff]|i', '', $url);
        $strip = array('%0d', '%0a', '%0D', '%0A');
        $url = (string) $url;
        $count = 1;
        while ($count) {
            $url = str_replace($strip, '', $url, $count);
        }
        $url = str_replace(';//', '://', $url);
        $url = htmlentities($url);
        $url = str_replace('&amp;', '&#038;', $url);
        $url = str_replace("'", '&#039;', $url);
        if ($url[0] !== '/') {
            // We're only interested in relative links from $_SERVER['PHP_SELF']
            return '';
        } else {
            return $url;
        }
    }

    // Function to generate admin logs.
    function generateAdminLogs ($mysqli) {
        // Generate upload log
        generateUploadLog ($mysqli,UPLOAD_LOG_TABLE,UPLOAD_LOG_FILE_ADMIN);
        // Generate workspace deploy log
        generateWorkspaceLog ($mysqli,WORKSPACE_DEPLOY_LOG_TABLE,WORKSPACE_DEPLOY_LOG_FILE_ADMIN);
        // Generate dispatch log
        generateDispatchLog ($mysqli, DISPATCH_LOG_TABLE, DISPATCH_LOG_FILE_ADMIN);
        // Generate student details log
        generateStudentDetailsLog ($mysqli,STUDENT_DETAILS_TABLE, STUDENT_DETAILS_FILE_ADMIN);
        // Generate login attempts log
        generateLoginAttemptsLog ($mysqli, LOGIN_ATTEMPTS_TABLE, LOGIN_ATTEMPTS_LOG_ADMIN);
    }

    // Function to generate upload log from the database.
    function generateUploadLog ($mysqli,$uploadLogTable,$uploadLogFile) {
        chdir (LOG_FOLDER);
        chdir ("admin");
        if ($stmt = $mysqli->prepare("SELECT * FROM $uploadLogTable")) {
            $stmt->execute();
            $stmt->store_result();
            // If no rows exist.
            if ($stmt->num_rows < 1)
                return;
            if (!($logFileHandler = fopen($uploadLogFile, 'w')))
                return;
            fputcsv($logFileHandler, array("TIMESTAMP","ID","IP","FILENAME","OUTPUT"));
            $stmt->bind_result($timestamp,$id,$ip,$filename,$output);
            while ($stmt->fetch()) {
                fputcsv($logFileHandler, array($timestamp,$id,$ip,$filename,$output));
            }
            fclose($logFileHandler);
            $stmt->close();
       }
    }

        // Function to generate workspace deploy log from the database.
    function generateWorkspaceLog ($mysqli,$workspaceLogTable,$workspaceLogFile) {
        chdir (LOG_FOLDER);
        chdir ("admin");
        if ($stmt = $mysqli->prepare("SELECT * FROM $workspaceLogTable")) {
            $stmt->execute();
            $stmt->store_result();
            // If no rows exist.
            if ($stmt->num_rows < 1)
                return;
            if (!($logFileHandler = fopen($workspaceLogFile, 'w')))
                return;
            fputcsv($logFileHandler, array("TIMESTAMP","ID","IP","FILENAME","OUTPUT"));
            $stmt->bind_result($timestamp,$id,$ip,$filename,$output);
            while ($stmt->fetch()) {
                fputcsv($logFileHandler, array($timestamp,$id,$ip,$filename,$output));
            }
            fclose($logFileHandler);
            $stmt->close();
       }
    }    

    // Function to generate dispatch log from the database.
    function generateDispatchLog ($mysqli,$dispatchLogTable,$dispatchLogFile) {
        chdir (LOG_FOLDER);
        chdir ("admin");
        if ($stmt = $mysqli->prepare("SELECT * FROM $dispatchLogTable")) {
            $stmt->execute();
            $stmt->store_result();
            // If no rows exist.
            if ($stmt->num_rows < 1)
                return;
            if (!($logFileHandler = fopen($dispatchLogFile, 'w')))
                return;
            fputcsv($logFileHandler, array("TIMESTAMP","ID","IP","WAYPOINT","OUTPUT"));
            $stmt->bind_result($timestamp,$id,$ip,$waypoint,$output);
            while ($stmt->fetch()) {
                fputcsv($logFileHandler, array($timestamp,$id,$ip,$waypoint,$output));
            }
            fclose($logFileHandler);
            $stmt->close();
       }
    }    

    // Function to generate student details log from the database.
    function generateStudentDetailsLog ($mysqli,$studentDetailsLogTable,
        $studentDetailsLogFile) {
        chdir (LOG_FOLDER);
        chdir ("admin");
        if ($stmt = $mysqli->prepare("SELECT * FROM $studentDetailsLogTable")) {
            $stmt->execute();
            $stmt->store_result();
            // If no rows exist.
            if ($stmt->num_rows < 1)
                return;
            if (!($logFileHandler = fopen($studentDetailsLogFile, 'w')))
                return;
            fputcsv($logFileHandler, array("ID","COMPLETE_NAME","MODIFIED TIMESTAMP"));
            $stmt->bind_result($id,$c_name,$timestamp);
            while ($stmt->fetch()) {
                fputcsv($logFileHandler, array($id, $c_name, $timestamp));
            }
            fclose($logFileHandler);
            $stmt->close();
       }
    }    

    // Function to generate login attempts logs from the database.
    function generateLoginAttemptsLog ($mysqli,$loginAttemptsLogTable,
        $loginAttemptsLogFile) {
        chdir (LOG_FOLDER);
        chdir ("admin");
        if ($stmt = $mysqli->prepare("SELECT * FROM $loginAttemptsLogTable")) {
            $stmt->execute();
            $stmt->store_result();
            // If no rows exist.
            if ($stmt->num_rows < 1)
                return;
            if (!($logFileHandler = fopen($loginAttemptsLogFile, 'w')))
                return;
            fputcsv($logFileHandler, array("TIMESTAMP","ID","IP","RESULT"));
            $stmt->bind_result($timestamp,$id,$ip,$result);
            while ($stmt->fetch()) {
                fputcsv($logFileHandler, array($timestamp,$id,$ip,$result));
            }
            fclose($logFileHandler);
            $stmt->close();
       }
    }
?>