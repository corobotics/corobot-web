<?php
    include_once 'folder_config.php';

    // Function to create the desired files and folders for each user.
    function createFoldersAndFiles ($id,$is_admin) {

        // Create the folders.
        checkOrCreateFolder ($id,LOG_FOLDER);
        checkOrCreateFolder ($id,UPLOAD_FOLDER);

        // Create the files.
        $folderName = LOG_FOLDER . "/" . $id;
        createFile ($folderName, $id . DISPATCH_LOG_FILE);
        createFile ($folderName, $id . UPLOAD_LOG_FILE);
        createFile ($folderName, $id . WORKSPACE_DEPLOY_LOG_FILE);

        // Create admin specific logs.
        if ($is_admin) {
            createFile ($folderName, DISPATCH_LOG_FILE_ADMIN);
            createFile ($folderName, UPLOAD_LOG_FILE_ADMIN);
            createFile ($folderName, WORKSPACE_DEPLOY_LOG_FILE_ADMIN);
            createFile ($folderName, STUDENT_DETAILS_FILE_ADMIN);
            createFile ($folderName, LOGIN_ATTEMPTS_LOG_ADMIN);
        }
    }

    // Function to check if a folder exists or not. If not, create one.
    function checkOrCreateFolder ($id,$folderName) {
        chdir ($folderName);
        if (!is_dir($id)) {
            mkdir($id);
            chmod($id, FOLDER_PERMISSION);
        }
    }

    // Function to create files for each user.
    function createFile ($folderName ,$fileName) {
        chdir($folderName);
        if (!file_exists("$fileName")) {
            shell_exec("touch $fileName");
            chmod("$fileName", FILE_PERMISSION);
        }
    }
?>