<?php
    include_once 'db_config.php';
    include_once 'db_connect.php';
    include_once 'admin.php';
    include_once 'dn_names.php';

    //define ("STUDENT_DETAILS_TABLE", "student_details");
    //define ("LOGIN_ATTEMPTS_TABLE", "login_attempts");

    function authenticate ($id, $password, $mysqli) {
        if (ldapAuthentication ($id, $password, $mysqli) ||
            adminAuthentication ($id, $password, $mysqli)) {
            // Store the successful login attempt
            addLoginAttempt($id,true,$mysqli);
            return true;
        }
        else {
            // Store the failed login attempt
            addLoginAttempt($id,false,$mysqli);
            return false;
        }
    }

    // authenticate using Adam's code. Plain direct ldap connection
    function ldapAuthentication ($id, $password, $mysqli) {
        $dn = "uid=$id, ";
        $basedn="ou=people,dc=rit,dc=edu";
        $filter = "(uid=$id)"; 
        
        $connect = @ldap_connect('ldap.rit.edu');
        if (!$connect OR !(@ldap_bind($connect, $dn . $basedn, $password)) OR empty($password)) {
            // Return approriate reason for failure.
            return false;
        }

        $data = ldap_get_entries($connect, ldap_search($connect, $basedn, $filter));
        $completeName = $data[0]['cn'][0];
        // Store the successful login attempt
        //addLoginAttempt($id,true,$mysqli);
        // Check for new/returing users and complet_name
        
        if (debutCheck ($id, $completeName, $mysqli)) {
            $user_browser = $_SERVER['HTTP_USER_AGENT'];
            // XSS protection as we might print this value
            $id = preg_replace("/[^a-zA-Z0-9]+/", "", $id);
            $_SESSION['id'] = $id;
            $_SESSION['login_string'] = hash('sha512', ($user_browser . $id . $completeName));
            return true;
        }
        else
            return false;
    }

    /*
     * Function to authenticate the admin.
       Requires : admin.php to be included.
     */ 
    function adminAuthentication ($id, $password, $mysqli) {
        if (defined("ADMIN_PASSWORD") && (defined ("ADMIN_ID")) && (defined("ADMIN_NAME"))) {
            if (($id == ADMIN_ID) && ($password == ADMIN_PASSWORD)) {
                if (debutCheck ($id, ADMIN_NAME, $mysqli)) {
                    $user_browser = $_SERVER['HTTP_USER_AGENT'];
                    // XSS protection as we might print this value
                    $id = preg_replace("/[^a-zA-Z0-9]+/", "", $id);
                    $_SESSION['id'] = $id;
                    $_SESSION['admin'] = true;
                    $_SESSION['login_string'] = hash('sha512', ($user_browser . $id . ADMIN_NAME));
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }
        else {
            header('Location : /error.php?err="Unable to validate admin details."');
            return false;
        }
    }

    /*
     * Function to store the login attempt and its result - Success or failure.
    */
    function addLoginAttempt ($id,$loginResult,$mysqli) {
        $loginResult = ($loginResult == true)? "SUCCESS" : "FAILED";
        if ($stmt = $mysqli->prepare ("INSERT INTO " . LOGIN_ATTEMPTS_TABLE . 
            " (id,ip4_addr,result) VALUES (?,?,?)")) {
            $stmt->bind_param ("sss",$id,$_SERVER['REMOTE_ADDR'],$loginResult);
            $stmt->execute();
        }
        else
            header('Location : /error.php?err="Unable to store login attempt."');
    }

    /*
     * Function to check for debut users. Verifies/adds the complete name to the
     * database, which is used for logged_in_check().
       Returns  'True' : If the user (either new or returning), is updated to the database.
                'False' : If unable to add details to the database.
     */
    function debutCheck ($id, $completeName, $mysqli) {
        if ($stmt = $mysqli->prepare("SELECT complete_name 
            FROM " . STUDENT_DETAILS_TABLE . " WHERE id = ?")) {
            $stmt->bind_param('s', $id);
            $stmt->execute();
            $stmt->store_result();
            $stmt->bind_result($c_name);
            $stmt->fetch();
            // Check is user is new or returning, check the complete_name.
            if (($stmt->num_rows < 1) || ($completeName != $c_name)) {
                if (!addCompleteName ($id, $completeName, $mysqli))
                    //return false;
                    header('Location: /error.php?err="Unable to add completeName in addCompleteName()"');
            }
            return true;
        }
        else
            //return false;
            header('Location: /error.php?err="False returned in debutCheck()"');
    }

    /*
     * Function to add complete name for the 'id' to the database.
     * Returns 'true' on success, 'false' otherwise.
     */
    function addCompleteName ($id, $completeName, $mysqli) {
        // Check if 'id' is a new user.
        if ($stmt = $mysqli->prepare ("SELECT COUNT(*) 
            FROM " . STUDENT_DETAILS_TABLE . " WHERE id=?")) {
            $stmt->bind_param('s', $id);
            $stmt->execute();
            $stmt->store_result();
            $stmt->bind_result($count);
            $stmt->fetch();
            // Returning user -  update the complete name it to the database.
            if ($count == 1) {
                if ($stmt = $mysqli->prepare("UPDATE " . STUDENT_DETAILS_TABLE . 
                    " SET complete_name=? WHERE id=?")) {
                    $stmt->bind_param('ss',$completeName,$id);
                    $stmt->execute();
                    //$stmt->store_result();
                }
                else 
                    //return false;
                    header('Location: /error.php?err="Unable to update table"');
            } 
            // New user - add its details to the database.
            else {
                if ($stmt = $mysqli->prepare("INSERT INTO " .
                    STUDENT_DETAILS_TABLE . " (id,complete_name) VALUES (?,?)")) {
                    $stmt->bind_param('ss',$id,$completeName);
                    $stmt->execute();
                } 
                else
                    //return false;
                    header('Location: /error.php?err="Unable to add new record"');
            }
            return true;
        }
        // Some error while perform database operations.
        //return false;
        header('Location: /error.php?err="Some error while performing database operations"');
    }
?>