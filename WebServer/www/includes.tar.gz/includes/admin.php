<?php
/**
* These are the admin login details
*/      
    define ("ADMIN_ID","admin");
    define("ADMIN_PASSWORD", "iworkatRIT");
    define ("ADMIN_NAME","ADMIN");
?>