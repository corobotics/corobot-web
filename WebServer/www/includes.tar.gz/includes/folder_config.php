<?php
    // Folders to be created
    define ("LOG_FOLDER", "/var/www/logs");
    define ("UPLOAD_FOLDER", "/var/www/uploads/");
    // Files to be created.
    define ("UPLOAD_LOG_FILE", "_uploadLog.txt");
    define ("WORKSPACE_DEPLOY_LOG_FILE", "_workspaceDeployLog.txt");
    define ("DISPATCH_LOG_FILE", "_dispatchLog.txt");
    // Admin files to be created.
    define ("UPLOAD_LOG_FILE_ADMIN", "uploadLog_admin.csv");
    define ("WORKSPACE_DEPLOY_LOG_FILE_ADMIN", "workspaceDeployLog_admin.csv");
    define ("DISPATCH_LOG_FILE_ADMIN", "dispatchLog_admin.csv");
    define ("STUDENT_DETAILS_FILE_ADMIN","studentDetails_admin.csv");
    define ("LOGIN_ATTEMPTS_LOG_ADMIN","loginAttemptsLog_admin.csv");
    // Folder perimissions
    define ("FOLDER_PERMISSION",0777);
    // File permissions
    define ("FILE_PERMISSION",0666);
?>