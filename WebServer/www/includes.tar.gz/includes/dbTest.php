<?php
    include_once 'db_connect.php';
    include_once 'functions.php';
    echo "Start<br>";
    generateAdminLogs($mysqli);
    echo "End<br>";
?>