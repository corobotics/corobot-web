<?php
    // Names of all the database tables.
    define ("STUDENT_TABLE", "student_info");
    define ("STUDENT_DETAILS_TABLE", "student_details");
    define ("OLD_LOGIN_ATTEMPT_TABLE", "old_login_attempts");
    define ("LOGIN_ATTEMPTS_TABLE", "login_attempts");
    define ("WORKSPACE_DEPLOY_LOG_TABLE", "workspace_deploy_log");
    define ("UPLOAD_LOG_TABLE", "upload_log");
    define ("DISPATCH_LOG_TABLE", "dispatch_log");
?>